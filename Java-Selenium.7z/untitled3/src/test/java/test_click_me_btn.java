import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.junit.Assert.assertTrue;

public class test_click_me_btn {
    public static void main(String[] args) {
        System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
        ChromeDriver browser = new ChromeDriver();
        browser.manage().window().maximize();
        browser.get("https://demoqa.com/buttons");
        WebElement click_me_btn = browser.findElement(By.xpath("//button[text()='Click Me']"));
        click_me_btn.click();
        String assert_text = browser.findElement(By.xpath("//button[text()='Click Me']")).getText();
        assertTrue("Text", assert_text.contains("Click Me"));
        System.out.println("Проверка успешна");
        browser.close();
    }

    public static class test_dnmc_btn {
        public static void main(String[] args) {
            System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
            ChromeDriver browser = new ChromeDriver();
            browser.manage().window().maximize();
            browser.get("https://demoqa.com/dynamic-properties");
            WebElement button_visible = new WebDriverWait(browser, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("visibleAfter")));
            button_visible.click();
        }

        public static class test_adding_10_users {
            public static void main(String[] args) throws InterruptedException {
                System.setProperty("webdriver.chrome.driver", "C:\\Selenium\\chromedriver.exe");
                ChromeDriver browser = new ChromeDriver();
                browser.manage().window().maximize();
                browser.get("https://demoqa.com/webtables");
                String[] firstName = {"Rachel", "Amanda", "Amber", "John", "Nikolai", "Max", "Rob", "Ricky", "Chris", "Keisha",
                        "Dmitri", "Alexander", "Dennis", "Lebron", "Brandon", "Juan", "Alex", "Oleksandr", "Tasha", "Tatiana", "Olivia", "Curtis", "Emma", "Ava", "Charlotte", "Elijah", "Mary", "Patricia", "Linda", "Barbara", "Elizabeth", "Jennifer", "Maria", "Susan", "Margaret", "Dorothy", "Lisa", "Nancy", "Karen", "Betty", "Sharon", "Carol", "Sandra", "Ruth", "Michelle", "Angela", "Melissa", "Virginia"};
                String[] lastName = {"Clamps", "Nunes", "Rex", "Doe", "Vachovski", "Garcia", "Font", "Rubio", "Tucker", "Green", "Smith", "Johnson", "Williams", "Brown", "Jones", "Davis", "Miller", "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas", "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White", "Curry", "Harris", "Leonard", "Sanchez", "Clark", "Lewis", "Robinson", "Walker", "Young", "Allen", "King", "Wright", "Scott", "Torres"};
                String[] email = {"ro@ro.com", "ta@cos.com", "com@misar.com", "ro@pz.com", "true@crime.com", "never@surrender.com",
                        "heavy@meansreliable.com", "bas@sketball.com", "gor@ra.com", "chance@gmail.com", "fault@gmail.com", "rickyrock@outlook.com", "rpp@outlook.com", "shiftforever@mail.ru", "shift2022@gmail.com", "shiftvsegda@yandex.ru", "cftvpered@gmail.com", "teethtooth@miller.com", "feetihave@gmail.com", "handsihave@gmail.com", "headihave@gmail.com", "earsihave@gmail.com", "fingersihave@gmail.com", "scissorsihave@mail.ru", "eyesihave@gmail.com", "eyelids@gmail.com", "drum@mail.ru", "pocketsempty@gmail.com", "needinsurance@gmail.com", "damnitsbrian@gmail.com", "quepasohota@gmail.com", "dominick@gmail.com", "tobeoornottobe@outlook.com", "healthynot@outlook.com", "believeachievefail@outlook.com", "bombaster@mail.ru", "shipychka@mail.ru", "scramble@book.com", "reeadit@gmail.com", "rememberforget@gmail.com", "roundone@gmail.com", "roundtwo@gmail.com"};
                int age_number = 18 + new Random().nextInt(75);
                int salary_number = 2000 + new Random().nextInt(20000);
                String[] department = {"Insurance", "Compliance", "Legal", "Marketing"};
//            Random random = new Random();
//            int randomIdx = random.nextInt(firstName.length);
                WebElement add_btn = browser.findElement(By.id("addNewRecordButton"));
                add_btn.click();
                WebElement firstname_field = browser.findElement(By.id("firstName"));
                firstname_field.sendKeys(firstName[new Random().nextInt(firstName.length)]);
                WebElement lastname_field = browser.findElement(By.id("lastName"));
                lastname_field.sendKeys(lastName[new Random().nextInt(lastName.length)]);
                WebElement email_field = browser.findElement(By.id("userEmail"));
                email_field.sendKeys(email[new Random().nextInt(email.length)]);
                WebElement age_field = browser.findElement(By.id("age"));
                age_field.sendKeys(String.valueOf(age_number));
                WebElement salary_field = browser.findElement(By.id("salary"));
                salary_field.sendKeys(String.valueOf(salary_number));
                WebElement department_field = browser.findElement(By.id("department"));
                department_field.sendKeys(department[new Random().nextInt(department.length)]);
                WebElement submit_button = browser.findElement(By.id("submit"));
                submit_button.click();
                WebElement delete_button = browser.findElement(By.id("delete-record-3"));
                delete_button.click();
                List<WebElement> list = browser.findElements(By.className("rt-tr-group"));
                for (WebElement element : list) {
                    if (element.getText().contains("kierra@example.com")) {
                        System.out.println("It exists");
                    } else {
                        System.out.println("The record's been successfully deleted");
                    }
                    browser.get("https://demoqa.com/browser-windows");
//                    String mainWindow = browser.getWindowHandle();
//                    String mainWindowName = browser.getTitle();
//                    System.out.println("Main window is" + mainWindow);
//                    System.out.println("Name of the current, main window" + mainWindowName);
                    WebElement new_tab_button = browser.findElement(By.xpath("//button[text()='New Tab']"));
                    new_tab_button.click();
//                    String secondWindow = String.valueOf(browser.getWindowHandles());
//                    String secondWindowName = browser.getTitle();
//                    System.out.println("Name of the current, second window" + secondWindowName);
//                    System.out.println("Second window" + secondWindow);
                    ArrayList tabs = new ArrayList(browser.getWindowHandles());
                    System.out.println(tabs.size());
                    browser.switchTo().window((String) tabs.get(0));
                    String mainWindowName = browser.getTitle();
                    System.out.println(mainWindowName);
                    browser.switchTo().window((String) tabs.get(1));
                    Thread.sleep(2);
                    String secondWindowName = browser.getTitle();
                    System.out.println(secondWindowName);
                    WebDriverWait wait = new WebDriverWait(browser, Duration.ofSeconds(10));
                    wait.until(ExpectedConditions.numberOfWindowsToBe(2));
                    WebElement new_tab_opened = new WebDriverWait(browser, Duration.ofSeconds(10)).until(ExpectedConditions.visibilityOfElementLocated(By.id("sampleHeading")));
                    System.out.println(new_tab_opened.getText());
                    String assert1_text = browser.findElement(By.id("sampleHeading")).getText();
                    System.out.println(assert1_text);

//                    wait.until(titleIs("https://demoqa.com/sample"));
//                    assertTrue(browser.getTitle().contains("This is a sample page"));


//                else {
//                    System.out.println("For WebElement" + element.getAttribute("innerHTML") + "seems it does not");
//                }
//            boolean user_deleted = list.stream().allMatch(webElement -> webElement.getText().equals("kierra@example.com"));
//            if(user_deleted)){
//    logger.info()
//            }
//            List<String> texts = new ArrayList<>();
//            for(WebElement element : list){
//                texts.put(element.getText());
//            }
//            boolean found = false;
//            for(String str: texts) {
//            if(str.trim().contains("kierra@example.com")){

                }

//            WebElement click_me_btn = browser.findElement(By.xpath("//button[text()='Click Me']"));
//            click_me_btn.click();
//            String assert_text = browser.findElement(By.xpath("//button[text()='Click Me']")).getText();
//            Assert.assertTrue("Text", assert_text.contains("Click Me"));
//            System.out.println("Проверка успешна");
//            browser.close();
//        }
//    }
//}
            }
        }
    }
}